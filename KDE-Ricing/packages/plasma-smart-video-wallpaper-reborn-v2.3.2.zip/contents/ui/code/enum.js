const PlaybackOverride = {
  Play: 0,
  Pause: 1,
  Default: 2,
};

const MuteOverride = {
  Mute: 0,
  Unmute: 1,
  Default: 2,
};
